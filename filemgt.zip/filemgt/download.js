/**
 * Module dependencies.
 */

var express = require('../../');
var path = require('path');
var router = express.Router();
var fs = require('fs');

router.get('/issue', function(req, res){
  res.send('<ul>'
    + '<li>Download <a href="/download/amazing.txt">output.txt</a>.</li>'
    + '</ul>');
});

router.get('/',render() );


function render(){
	return function(request, response){
		//var url = request.url;
		var filename = 'output.txt';
		//url.substring(url.lastIndexOf('/')+1);
			//console.log('url: ' + url);
			console.log('   filename: ' + filename);
			var readStream = fs.createReadStream('./' + filename);
		    // We replaced all the event handlers with a simple call to readStream.pipe()
			response.writeHead(200, {'Content-Type': 'application/octet-stream',"Content-Disposition": "attachment; filename=" + filename}); 
		    readStream.pipe(response);
		    //response.end();
			//res.format(obj);
  };
}


// /files/* is accessed via req.params[0]
// but here we name it :file
router.get('/download/:file(*)', function(req, res, next){
  var filePath = path.join(__dirname, 'download', req.params.file);

  res.download(filePath, function (err) {
    if (!err) return; // file sent
    if (err && err.status !== 404) return next(err); // non-404 error
    // file for download not found
    res.statusCode = 404;
    res.send('Cant find that file, sorry!');
  });
});

module.exports = router;

