var express = require('../../');
var app = express();

var upload = require('./upload.js');
var download = require('./download.js');

//both index.js and things.js should be in same directory
app.use('/upload', upload);
app.use('/download', download);


app.listen(8000);